// Function to handle the click event on the navbar buttons
function handleNavClick(targetId) {
    // Remove the active class from all buttons
    document.querySelectorAll('.home-page-button').forEach(button => {
        button.classList.remove('active');
    });

    // Add the active class to the corresponding button in the homepage section
    document.getElementById(targetId).classList.add('active');
}

// Attach click event listeners to navbar links
document.querySelectorAll('.nav-link').forEach(navLink => {
    navLink.addEventListener('click', function() {
        const targetId = this.getAttribute('href').substring(1).toLowerCase() + '-button';
        handleNavClick(targetId);
    });
});
